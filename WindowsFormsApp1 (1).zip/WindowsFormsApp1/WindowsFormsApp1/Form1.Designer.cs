﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnum1 = new System.Windows.Forms.TextBox();
            this.txtnum2 = new System.Windows.Forms.TextBox();
            this.lblsoma = new System.Windows.Forms.Label();
            this.lblsubtracao = new System.Windows.Forms.Label();
            this.lblmultiplicacao = new System.Windows.Forms.Label();
            this.lbldivisao = new System.Windows.Forms.Label();
            this.btncalcular = new System.Windows.Forms.Button();
            this.lblsub = new System.Windows.Forms.Label();
            this.lbldiv = new System.Windows.Forms.Label();
            this.lblmult = new System.Windows.Forms.Label();
            this.lblsom = new System.Windows.Forms.Label();
            this.lblin2 = new System.Windows.Forms.Label();
            this.lblin1 = new System.Windows.Forms.Label();
            this.btnC = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtnum1
            // 
            this.txtnum1.Location = new System.Drawing.Point(53, 80);
            this.txtnum1.Name = "txtnum1";
            this.txtnum1.Size = new System.Drawing.Size(100, 20);
            this.txtnum1.TabIndex = 0;
            // 
            // txtnum2
            // 
            this.txtnum2.Location = new System.Drawing.Point(53, 164);
            this.txtnum2.Name = "txtnum2";
            this.txtnum2.Size = new System.Drawing.Size(100, 20);
            this.txtnum2.TabIndex = 3;
            // 
            // lblsoma
            // 
            this.lblsoma.AutoSize = true;
            this.lblsoma.Location = new System.Drawing.Point(325, 87);
            this.lblsoma.Name = "lblsoma";
            this.lblsoma.Size = new System.Drawing.Size(35, 13);
            this.lblsoma.TabIndex = 4;
            this.lblsoma.Text = "label1";
            // 
            // lblsubtracao
            // 
            this.lblsubtracao.AutoSize = true;
            this.lblsubtracao.Location = new System.Drawing.Point(443, 87);
            this.lblsubtracao.Name = "lblsubtracao";
            this.lblsubtracao.Size = new System.Drawing.Size(35, 13);
            this.lblsubtracao.TabIndex = 5;
            this.lblsubtracao.Text = "label2";
            // 
            // lblmultiplicacao
            // 
            this.lblmultiplicacao.AutoSize = true;
            this.lblmultiplicacao.Location = new System.Drawing.Point(325, 171);
            this.lblmultiplicacao.Name = "lblmultiplicacao";
            this.lblmultiplicacao.Size = new System.Drawing.Size(35, 13);
            this.lblmultiplicacao.TabIndex = 6;
            this.lblmultiplicacao.Text = "label3";
            // 
            // lbldivisao
            // 
            this.lbldivisao.AutoSize = true;
            this.lbldivisao.Location = new System.Drawing.Point(443, 171);
            this.lbldivisao.Name = "lbldivisao";
            this.lbldivisao.Size = new System.Drawing.Size(35, 13);
            this.lbldivisao.TabIndex = 7;
            this.lbldivisao.Text = "label4";
            // 
            // btncalcular
            // 
            this.btncalcular.Location = new System.Drawing.Point(53, 258);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(75, 23);
            this.btncalcular.TabIndex = 8;
            this.btncalcular.Text = "calcular";
            this.btncalcular.UseVisualStyleBackColor = true;
            this.btncalcular.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblsub
            // 
            this.lblsub.AutoSize = true;
            this.lblsub.Location = new System.Drawing.Point(443, 55);
            this.lblsub.Name = "lblsub";
            this.lblsub.Size = new System.Drawing.Size(54, 13);
            this.lblsub.TabIndex = 9;
            this.lblsub.Text = "subtração";
            // 
            // lbldiv
            // 
            this.lbldiv.AutoSize = true;
            this.lbldiv.Location = new System.Drawing.Point(443, 143);
            this.lbldiv.Name = "lbldiv";
            this.lbldiv.Size = new System.Drawing.Size(40, 13);
            this.lbldiv.TabIndex = 10;
            this.lbldiv.Text = "divisão";
            // 
            // lblmult
            // 
            this.lblmult.AutoSize = true;
            this.lblmult.Location = new System.Drawing.Point(325, 143);
            this.lblmult.Name = "lblmult";
            this.lblmult.Size = new System.Drawing.Size(68, 13);
            this.lblmult.TabIndex = 11;
            this.lblmult.Text = "multiplicação";
            // 
            // lblsom
            // 
            this.lblsom.AutoSize = true;
            this.lblsom.Location = new System.Drawing.Point(325, 55);
            this.lblsom.Name = "lblsom";
            this.lblsom.Size = new System.Drawing.Size(32, 13);
            this.lblsom.TabIndex = 12;
            this.lblsom.Text = "soma";
            // 
            // lblin2
            // 
            this.lblin2.AutoSize = true;
            this.lblin2.Location = new System.Drawing.Point(50, 143);
            this.lblin2.Name = "lblin2";
            this.lblin2.Size = new System.Drawing.Size(87, 13);
            this.lblin2.TabIndex = 13;
            this.lblin2.Text = "Insira um número";
            // 
            // lblin1
            // 
            this.lblin1.AutoSize = true;
            this.lblin1.Location = new System.Drawing.Point(50, 55);
            this.lblin1.Name = "lblin1";
            this.lblin1.Size = new System.Drawing.Size(87, 13);
            this.lblin1.TabIndex = 14;
            this.lblin1.Text = "Insira um número";
            // 
            // btnC
            // 
            this.btnC.Location = new System.Drawing.Point(134, 258);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(75, 23);
            this.btnC.TabIndex = 15;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = true;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.lblin1);
            this.Controls.Add(this.lblin2);
            this.Controls.Add(this.lblsom);
            this.Controls.Add(this.lblmult);
            this.Controls.Add(this.lbldiv);
            this.Controls.Add(this.lblsub);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.lbldivisao);
            this.Controls.Add(this.lblmultiplicacao);
            this.Controls.Add(this.lblsubtracao);
            this.Controls.Add(this.lblsoma);
            this.Controls.Add(this.txtnum2);
            this.Controls.Add(this.txtnum1);
            this.Name = "Form1";
            this.Text = "Calculadora";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtnum1;
        private System.Windows.Forms.TextBox txtnum2;
        private System.Windows.Forms.Label lblsoma;
        private System.Windows.Forms.Label lblsubtracao;
        private System.Windows.Forms.Label lblmultiplicacao;
        private System.Windows.Forms.Label lbldivisao;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.Label lblsub;
        private System.Windows.Forms.Label lbldiv;
        private System.Windows.Forms.Label lblmult;
        private System.Windows.Forms.Label lblsom;
        private System.Windows.Forms.Label lblin2;
        private System.Windows.Forms.Label lblin1;
        private System.Windows.Forms.Button btnC;
    }
}

